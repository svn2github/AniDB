(C) 2003-2007 by DonGato
Version: 3.2 (07.07.2007)

This package includes the images for the light blue HTML template

Instalation of images:
======================
Copy all the files into a directory named 'images' where the mylist.htm file is placed.

root_dir
 |
 +-- anime
 +-- images
 +-- style.css
 +-- styleg.css
 +-- stylew.css
 +-- anime.htm
 +-- anime_opera.htm
 +-- mylist.htm
 +-- code.js
 +-- mylist.js
 +-- changelog.txt
